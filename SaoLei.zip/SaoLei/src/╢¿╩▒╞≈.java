import java.util.Timer;
import java.util.TimerTask;

public class 定时器 {
  public static void time() {

  }
}
